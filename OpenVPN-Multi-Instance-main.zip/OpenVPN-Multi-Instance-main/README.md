# OpenVPN
Bash file tested on Ubuntu 20.04 that allow to create a OpenVPN Server installation with multiple instance based on Nyr/openvpn-install.


# Installation

Run the script and follow the assistant:

wget https://raw.githubusercontent.com/carmine1990/OpenVPN/main/openvpn.sh -O openvpn.sh && bash openvpn.sh

Once it ends, you can run it again to add more clients, OpenVPN instances (based on the client's IP), remove them, check and manage the OpenVPN instance or IPTables config services or even completely uninstall OpenVPN.
